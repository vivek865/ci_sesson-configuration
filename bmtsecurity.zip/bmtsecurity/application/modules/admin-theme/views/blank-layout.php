<?php $this->load->view('includes/blank-layout-head') ; ?>
<body class="hold-transition login-page">

<?php $this->load->view($main_content) ; ?>
<!-- jQuery 2.2.0 -->
<?php $this->load->view('includes/blank-layout-footer')  ;?>