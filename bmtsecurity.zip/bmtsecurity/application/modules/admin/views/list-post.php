<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Post List </h3> <h3 class="box-title" style=" float:right ; margin-right: 50% "> <a href="" class="btn btn-sm btn-success"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Post </a></h3>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
             
                <tbody>
                <tr>
                <th>Id</th>
                <th>Author</th>
                <th>Post Title</th>
                <th>Post Categories</th>
                <th>Posted On</th>
                <th>Edit</th>
                <th>Delete</th>
                </tr>
                
                 <?php // foreach($users as $user){?> <tr>
                  <td><?php // echo $user->id ;?></td>
                  <td><?php // echo $user->user_login ;?></td>
                  <td><?php // echo $user->user_nicename ;?></td>
                  <td><?php // echo $user->user_email ; ?></td>
                  <td><?php  //echo $user->registered_date  ; ?> </td>
                  <td><a href="#" class="label label-primary"><i class="fa fa-pencil-square-o " aria-hidden="true"> </i> Edit </a> </td>
                  <td><a href="<?php echo base_url() . "admin/delete_post/" ; // $user->id  ; ?> " class="label label-danger" > <i class="fa fa-minus-circle " aria-hidden="true"> </i> Delete</a></td>
                </tr>
                   <?php // }?>  
                
              </tbody></table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>